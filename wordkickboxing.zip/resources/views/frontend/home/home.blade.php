@extends('frontend.app')
@section('title')
    <title>Kick Boxing</title>
@endsection
@section('content')
    <div class="slider">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="sli-btn">
                        <a href="#">Register for<br>competition</a>
                        <a href="#">create new<br>competition</a>
                        <a href="#">register for<br>gala</a>
                        <a href="#">create new<br>gala</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
