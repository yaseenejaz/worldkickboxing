$(document).ready(function() {


	$('.editable-inline').editable({mode: 'inline'});    
	
});

