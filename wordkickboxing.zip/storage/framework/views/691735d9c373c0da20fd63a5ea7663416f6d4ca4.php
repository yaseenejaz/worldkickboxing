<ul class="nav nav-tabs">
    <li class="nav-item <?php echo e(Request::url() == route('user', $slug) ? 'navActive' : null); ?>">
        <a class="nav-link" href="<?php echo e(route('user', auth()->user()->slug)); ?>">Tournament</a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == route('user.tournament.ranking', $slug) ? 'navActive' : null); ?>">
        <a class="nav-link" href="<?php echo e(route('user.tournament.ranking', auth()->user()->slug)); ?>">Ranking</a>
    </li>
</ul>
<?php /**PATH C:\xampp\htdocs\world_kick_boxing\resources\views/frontend/user/subNavHeader.blade.php ENDPATH**/ ?>