<div class="col-xl-4">
    <nav class="nav-sidebar">
        <ul class="nav tabs">




            <li class="<?php echo e((request()->is('general')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('general',$tournament->slug)); ?>">General</a>
              </li>
            <li class="<?php echo e((request()->is('registration_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('registration.setting',$tournament->slug)); ?>">Registration</a></li>
            <li class="<?php echo e((request()->is('venue_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('venue.setting',$tournament->slug)); ?>">Venue</a></li>
            <li class="<?php echo e((request()->is('image_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('image.setting',$tournament->slug)); ?>">Images</a></li>
            <li class="<?php echo e((request()->is('draw_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('draw.setting',$tournament->slug)); ?>">Draws</a></li>
            <li class="<?php echo e((request()->is('entry_fees_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('entry.setting',$tournament->slug)); ?>">Entry Fees</a></li>
            <li class="<?php echo e((request()->is('payment_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('payment.setting',$tournament->slug)); ?>">Payments</a></li>
            <li class="<?php echo e((request()->is('document_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('document.setting',$tournament->slug)); ?>">Documents</a></li>
            <li class="<?php echo e((request()->is('email_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('email.setting',$tournament->slug)); ?>">Emails</a></li>
            <li class="<?php echo e((request()->is('permission_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('permission.setting',$tournament->slug)); ?>">Permissions</a></li>
            <li class="<?php echo e((request()->is('result_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('result.setting',$tournament->slug)); ?>">Results</a></li>
            <li class="<?php echo e((request()->is('certificate_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('certificate.setting',$tournament->slug)); ?>">Certificates</a></li>
            <li class="<?php echo e((request()->is('weigh_in_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('weigh.setting',$tournament->slug)); ?>">Weigh-in</a></li>
            <li class="<?php echo e((request()->is('license_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('license.setting',$tournament->slug)); ?>">Licenses</a></li>
            <li class="<?php echo e((request()->is('physical_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('physical.setting',$tournament->slug)); ?>">Physical</a></li>
            <li class="<?php echo e((request()->is('data_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('data.setting',$tournament->slug)); ?>">Data</a></li>
        </ul>
    </nav>
</div>
<?php /**PATH D:\laragon\www\wordkickboxing\resources\views/frontend/setting/sidebar.blade.php ENDPATH**/ ?>