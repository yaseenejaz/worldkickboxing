
<?php $__env->startSection('title'); ?>
    <title>Tournament Info</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <link rel="stylesheet" type="text/css"
          href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .save_button {
            background: #e04529;
            color: #fff;
            padding: 10px 30px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.5s ease;
            border: none;
        }
        .save_button:hover {
            transition: all 0.5s ease;
            background: #000;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<<section class="untitled">
        <h2><?php echo e($tournament->name); ?></h2>
        <?php
            $date = explode("-",$tournament->date);
            $month = DateTime::createFromFormat('!m', $date[1]);
            $month = $month->format('F');
            $today = date(" " . $date[2] . ", " . $date[0]);
        ?>
        <span><?php echo e($month . $today); ?></span>
    </section>

<?php echo $__env->make('frontend.tournament.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="padd">
	<div class="container">
		<div class="row">
			<div class="col-xl-12">
				<div class="cyp">
					
					<h2>Registration</h2>
				</div>
				<div class="search-list">
					<input type="text" name="Search..." placeholder="Search...">
					<a href="<?php echo e(route('tournament.orgnaization',$tournament->slug)); ?>">
						<img src="<?php echo e(asset('frontend/images/plus.png')); ?>">
						<span>New School</span>
					</a>
					<a href="#">
						<img src=" <?php echo e(asset('frontend/images/envelope.png')); ?>">
						<span>Send Invitations</span>
					</a>
					<a href="#">
						<img src="<?php echo e(asset('frontend/images/printer.png ')); ?>">
						<span>Print All Schools</span>
					</a>
					<a href="#" class="imp-sch">
						<img src="<?php echo e(asset('frontend/images/black-plus.png')); ?>">
						<span>Import Schools...</span>
					</a>
				</div>
				<?php if(!empty($Schools)): ?>
				<div class="r-box">
					<p></p>
	</div>

				<?php else: ?>
				<div class="r-box">
					<p>No schools registered yet!</p>
					<a href="#">
						<img src="<?php echo e(asset('frontend/images/wheel.png')); ?>">
						<span>SETTINGS</span>
					</a>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\world_kick_boxing\resources\views/frontend/tournament/registration.blade.php ENDPATH**/ ?>