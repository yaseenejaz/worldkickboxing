<?php $__env->startSection('title'); ?>
    <title>Competitors | <?php echo e($slug); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <style>
        .navActive {
            transition: all 0.5s ease;
            background: #df4428;
            border-radius: 5px;
            color: #fff !important;
        }

        .navActive a {
            color: #fff !important;
        }
    </style>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet"
          id="bootstrap-css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="untitled">
        <h2><?php echo e($tournament->name); ?></h2>
        <?php
        $date = explode("-",$tournament->date);
        $month = DateTime::createFromFormat('!m', $date[1]);
        $month = $month->format('F');
        $today = date(" " . $date[2] . ", " . $date[0]);
        ?>
        <span><?php echo e($month . $today); ?></span>
    </section>
    <?php echo $__env->make('frontend.tournament.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="ver-tab">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <h2><?php echo e($event->name); ?></h2>
                    <div class="pow-in">
                        <?php echo $__env->make('frontend.event.navHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade active in" id="competitors" role="tabpanel" aria-labelledby="competitors-tab">
                                <div class="search-list">
                                    <input type="text" name="Search..." placeholder="Search...">
                                </div>
                                <div class="pow-com">
                                    <div class="pow-box">
                                        <p>No Competitor Yet</p>
                                        <div class="btns">
                                            
                                            <a href="<?php echo e(route('event.newcompetitor',$tournament->slug)); ?>"><i class="fa fa-plus"></i>New Competitor</a>
                                            <a href="#"><i class="fa fa-plus"></i>New School</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\world_kick_boxing\resources\views/frontend/event/competitors.blade.php ENDPATH**/ ?>