
<?php $__env->startSection('title'); ?>
    <title>School data</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <link rel="stylesheet" type="text/css"
          href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .save_button {
            background: #e04529;
            color: #fff;
            padding: 10px 30px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.5s ease;
            border: none;
        }
        .save_button:hover {
            transition: all 0.5s ease;
            background: #000;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="untitled">
        <h2><?php echo e($tournament->name); ?></h2>
        <?php
            $date = explode("-",$tournament->date);
            $month = DateTime::createFromFormat('!m', $date[1]);
            $month = $month->format('F');
            $today = date(" " . $date[2] . ", " . $date[0]);
        ?>
        <span><?php echo e($month . $today); ?></span>
    </section>

<?php echo $__env->make('frontend.tournament.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<section>
	<div class="compe">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					
					<div class="data">
						<div class="log">
							<div class="hd-bg">
								<h4>Logo</h4>
							</div>
						 	<span>
						 		<?php echo e($Schools->name); ?>

						 		<a href="#"><i class="fa fa-chevron-double-left"></i>Registration</a>
						 	</span>
						</div>
						<div class="btn-lst">
							<a href="<?php echo e(route('event.newcompetitor',$Schools->slug)); ?>"><i class="fa fa-plus"></i>New Competitor</a>
							<a href="#"><i class="fa fa-print"></i>Print..</a>
							<a href="#"><i class="fa fa-pencil"></i>Edit Divisions</a>
						</div>
						<div class="txt">
							<?php if(!empty($competitor)): ?>
							<?php
					        $count=0;
					        ?>
					        	<?php $__currentLoopData = $competitor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compitator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php
                              $count++;
							?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
							<h2>Competitors(<?php echo e($count); ?>)</h2>
							<?php endif; ?>
							<h6>New Competitor</h6>
						</div>
						<div class="sr-box">
							<input type="text" name="search" placeholder="Search">
							<div class="ic">
								<i class="fa fa-search"></i>
							</div>
						</div>
					
						<?php if(!empty($competitor)): ?>
						<table id="example" class="table table-striped table-bordered" style="width:100%">
					        <thead>
					            <tr>
					                <th class="cen one">#</th>
					                <th class="two">Name</th>
					                 <th class="thre">Categories</th>
					                <th class="cen one">Nationality</th>
					                <th class="cen one">Age</th>
					                <th class="cen one">Gender</th>
					               

					            </tr>
					        </thead>
					        <tbody><?php
					        $count=1;
					        ?>
					        	
					            <tr>
					            	<?php $__currentLoopData = $competitor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compitator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                <td class="cen one"><?php echo e($count++); ?></td>
					                <td class="bb two"><?php echo e($compitator->name); ?>  
					                	<div class="dropdown show">
										  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										    <i class="fa fa-cog"></i>
										  </a>

										  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
										    <a class="dropdown-item" href="#"><i class="fa fa-eye"></i>View Draw</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-bars"></i>View Match List</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-print"></i>Print Draw</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-print"></i>Print Competitor List</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-file"></i>Print Blank Draw</a>
										  </div>
										</div>
					                </td>
					             
					               
									
								<?php $__currentLoopData = $descipline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                <td class="thre"><?php echo e($value->name); ?></td>
					               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						
					                <td class="cen one"><?php echo e($compitator->nationality); ?></td>
					                <td class="cen one">5</td>
					                <td class="cen one">Male</td>
					            </tr> 
					            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?>
					            <table id="example" class="table table-striped table-bordered" style="width:100%">
					        <thead>
					            <tr>
					                <th class="cen one">#</th>
					                <th class="two">Name</th>
					                <th class="thre">Categories</th>
					                <th class="cen one">Nationality</th>
					                <th class="cen one">Age</th>
					                <th class="cen one">Gender</th>
					            </tr>
					        </thead>
					            <?php endif; ?>
					           <!--  <tr>
					                <td class="cen one">100</td>
					                <td class="bb two"><?php echo e($Schools->name); ?>

					                	<div class="dropdown show">
										  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										    <i class="fa fa-cog"></i>
										  </a>

										  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
										    <a class="dropdown-item" href="#"><i class="fa fa-eye"></i>View Draw</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-bars"></i>View Match List</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-print"></i>Print Draw</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-print"></i>Print Competitor List</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-file"></i>Print Blank Draw</a>
										  </div>
										</div>
					                </td>
					                <td class="thre"></td>
					                <td class="cen one">TUR</td>
					                <td class="cen one">5</td>
					                <td class="cen one">Male</td>
					            </tr>
					            <tr>
					                <td class="cen one">100</td>
					                <td class="bb two">aadna
					                	<div class="dropdown show">
										  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										    <i class="fa fa-cog"></i>
										  </a>

										  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
										    <a class="dropdown-item" href="#"><i class="fa fa-eye"></i>View Draw</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-bars"></i>View Match List</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-print"></i>Print Draw</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-print"></i>Print Competitor List</a>
										    <a class="dropdown-item" href="#"><i class="fa fa-file"></i>Print Blank Draw</a>
										  </div>
										</div>
					                </td>
					                <td class="thre"></td>
					                <td class="cen one">TUR</td>
					                <td class="cen one">5</td>
					                <td class="cen one">Male</td>
					            </tr>  -->        
					        </tbody>
					    </table>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\world_kick_boxing\resources\views/frontend/tournament/Schooldata.blade.php ENDPATH**/ ?>