<?php $__env->startSection('title'); ?>
    <title>Import Event</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <link rel="stylesheet" type="text/css"
          href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="untitled">
        <h2>Untitled Tournament</h2>
        <span>May 20,2020</span>
    </section>

    <?php echo $__env->make('frontend.setting.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section>
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="imp">
                        <p>Complete your profile so you'll be able log in later.</p>
                        <div class="imp-form">
                            <h2>Import Event</h2>
                            <span>
							<h4>Event to import</h4>
							<div class="sel-down">
								<select>
									<option>Pattern</option>
									<option>Sparring</option>
									<option>Power Test</option>
									<option>Special Techniques</option>
									<option>Team Patterns</option>
									<option>Self Defence Routine</option>
									<option>Team Sparring</option>
									<option>Team Power Test</option>
									<option>Team Special Techniques</option>
									<option>Traditional Sparring</option>
								</select>
							</div>
						</span>
                            <a href="#">Import</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script>

        jQuery(document).ready(function(){
            jQuery('.icon-menu').on('click',function(){

                jQuery('.nav-kick').slideToggle('fast');
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp_7_4\htdocs\world_kick_boxing\resources\views/frontend/event/import_event.blade.php ENDPATH**/ ?>