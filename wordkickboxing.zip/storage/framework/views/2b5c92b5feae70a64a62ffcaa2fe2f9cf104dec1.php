<ul class="nav nav-tabs">
    <li class="nav-item <?php echo e(Request::url() == route('user', $slug) || Request::url() == route('user.tournament.ranking', $slug) ? 'navActive' : null); ?>">
        <a class="nav-link" href="<?php echo e(route('user', auth()->user()->slug)); ?>"><i class="fa fa-user"></i>Your Profile</a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == route('billing', $slug) ? 'navActive' : null); ?>">
        <a class="nav-link" href="<?php echo e(route('billing', auth()->user()->slug)); ?>"><i class="fa fa-usd"></i>Billing</a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == route('account.setting', $slug) ? 'navActive' : null); ?>">
        <a class="nav-link" href="<?php echo e(route('account.setting', auth()->user()->slug)); ?>"><i class="fa fa-cog"></i>Account Settings</a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == route('stripe', $slug) ? 'navActive' : null); ?>">
        <a class="nav-link" href="<?php echo e(route('stripe', auth()->user()->slug)); ?>"><i class="fa fa-cc-stripe"></i>Stripe Setup</a>
    </li>
    <li class="nav-item <?php echo e(Request::url() == route('paypal', $slug) ? 'navActive' : null); ?>">
        <a class="nav-link" href="<?php echo e(route('paypal', auth()->user()->slug)); ?>"><i class="fa fa-paypal"></i>Paypal Setup</a>
    </li>
</ul>
<?php /**PATH E:\xampp_7_4\htdocs\world_kick_boxing\resources\views/frontend/user/navHeader.blade.php ENDPATH**/ ?>