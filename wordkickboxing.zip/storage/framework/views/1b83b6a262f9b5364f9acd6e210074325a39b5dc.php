<?php $__env->startSection('title'); ?>
    <title>Account Setting</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <style>
        .navActive {
            transition: all 0.5s ease;
            background: #df4428;
            border-radius: 5px;
            color: #fff !important;
        }

        .navActive a{
            color: #fff !important;
        }
    </style>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="untitled">
        <h2>Untitled Tournament</h2>
        <span>May 20,2020</span>
    </section>
    <?php echo $__env->make('frontend.guestUser.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="ver-tab">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <h2>Account Setting</h2>
                    <div class="pow-in">
                        <?php echo $__env->make('frontend.guestUser.navHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div>
                            <div class="pf">
                                <h2>Your Details</h2>
                                <div class="fmr">
                                    <div class="fld">
                                        <label>Name</label>
                                        <input type="text" name="name">
                                    </div>
                                    <div class="fld">
                                        <label>Email</label>
                                        <input type="email" name="email">
                                    </div>
                                    <div class="fld">
                                        <div class="wt-lab">
                                            <div class="rad-txt">
                                                <input type="radio" name="raid">
                                                <div class="rado"></div>
                                            </div>
                                            <p>Email me about new features and tournaments.</p>
                                        </div>
                                    </div>
                                    <div class="fld">
                                        <div class="wt-lab">
                                            <a href="#">Save</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pf">
                                <h2>Change Password</h2>
                                <div class="fmr">
                                    <div class="fld">
                                        <label>Old Password</label>
                                        <input type="Password" name="old-pass">
                                    </div>
                                    <div class="fld">
                                        <label>New Password</label>
                                        <input type="Password" name="new-pass">
                                    </div>
                                    <div class="fld">
                                        <div class="wt-lab">
                                            <a href="#">Save</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp_7_4\htdocs\world_kick_boxing\resources\views/frontend/guestUser/account_setting.blade.php ENDPATH**/ ?>