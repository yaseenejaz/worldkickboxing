<div class="tick-box">
    <?php $__currentLoopData = $descipline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desciplines): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rbx">
            <input type="checkbox" name="descipline[]" value="<?php echo e($desciplines->id); ?>">
            <div class="rdo"></div>
            <label><?php echo e($desciplines->name); ?></label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\laragon\www\wordkickboxing\resources\views/frontend/tournament/tournament_descipline.blade.php ENDPATH**/ ?>