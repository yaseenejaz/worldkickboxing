<?php $__env->startSection('title'); ?>
    <title>Profile</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <style>
        .navActive {
            transition: all 0.5s ease;
            background: #df4428;
            border-radius: 5px;
            color: #fff !important;
        }

        .navActive a {
            color: #fff !important;
        }
    </style>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet"
          id="bootstrap-css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="untitled">
        <h2><?php echo e(auth()->user()->name); ?></h2>
    </section>

    <section class="ver-tab">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <h2>Profile</h2>
                    <div class="pow-in">
                        <?php echo $__env->make('frontend.user.navHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div>
                            <div class="pf">
                                <div class="nt">
                                    <a href="<?php echo e(route('tournament.create')); ?>"><i class="fa fa-plus"></i>New Tournament</a>
                                    <a href="#"><i class="fa fa-plus"></i>New Ranking</a>
                                </div>
                                <div class="tb-in">
                                    <?php echo $__env->make('frontend.user.subNavHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <div>
                                        <div class="t-box">
                                            <?php if(isset($tournament) && $tournament->isNotEmpty()): ?>
                                                <?php $__currentLoopData = $tournament; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournaments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="mth">
                                                        <div class="pic">
                                                        </div>
                                                        <div class="txt">
                                                            <a href="<?php echo e(route('show.tournament', $tournaments->slug)); ?>"><?php echo e($tournaments->name); ?></a>
                                                            <?php
                                                            $date = explode("-",$tournaments->date);
                                                            $month = DateTime::createFromFormat('!m', $date[1]);
                                                            $month = $month->format('F');
                                                            $today = date(" " . $date[2] . ", " . $date[0]);
                                                            ?>
                                                            <p><?php echo e($month . $today); ?></p>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <p class="text-center text-danger" style="font-weight: 700; font-size: 18px">No tournaments available</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\world_kick_boxing\resources\views/frontend/user/profile.blade.php ENDPATH**/ ?>