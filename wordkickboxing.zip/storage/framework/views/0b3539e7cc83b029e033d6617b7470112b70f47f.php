<section class="in-nav">
    <div class="container">
        <div class="row">
            <div class="col-xl-8">
                <ul>
                    <li><a href="">home</a></li>
                    <li><a href="#">registration</a></li>
                    <li><a href="#">competitors</a></li>
                    <li><a href="#">categories</a></li>
                    <li><a href="#">draws</a></li>
                    <li><a href="#">schedule</a></li>
                    <li><a href="#">live</a></li>
                    <li><a href="#">results</a></li>
                </ul>
            </div>
            <div class="col-xl-4">
                <div class="set-btn">
                    <a href="#">
                        <img src="<?php echo e(asset('frontend/images/wheel.png')); ?>">
                        <span>SETTINGS</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH E:\xampp_7_4\htdocs\world_kick_boxing\resources\views/frontend/user/header.blade.php ENDPATH**/ ?>