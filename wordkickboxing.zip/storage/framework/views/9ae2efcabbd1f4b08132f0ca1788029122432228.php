<?php $__env->startSection('title'); ?>
    <title>Division | <?php echo e($slug); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <style>
        .navActive {
            transition: all 0.5s ease;
            background: #df4428;
            border-radius: 5px;
            color: #fff !important;
        }

        .navActive a {
            color: #fff !important;
        }
    </style>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet"
          id="bootstrap-css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="untitled">
        <h2><?php echo e($tournament->name); ?></h2>
        <?php
        $date = explode("-",$tournament->date);
        $month = DateTime::createFromFormat('!m', $date[1]);
        $month = $month->format('F');
        $today = date(" " . $date[2] . ", " . $date[0]);
        ?>
        <span><?php echo e($month . $today); ?></span>
    </section>
    <?php echo $__env->make('frontend.tournament.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="ver-tab">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <h2>Pattern</h2>
                    <div class="pow-in">
                        <?php echo $__env->make('frontend.event.navHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade active in" id="division" role="tabpanel" aria-labelledby="division-tab">
                                <div class="search-list">
                                    <a href="#" class="siing">
                                        <i class="fa fa-check"></i>
                                        <span>Done Editing</span>
                                    </a>
                                    <a href="#" class="siing">
                                        <i class="fa fa-copy"></i>
                                        <span>Copy All</span>
                                    </a>
                                    <a href="#" class="siing">
                                        <i class="fa fa-paste"></i>
                                        <span>Paste All</span>
                                    </a>
                                    <a href="#" class="siing">
                                        <i class="fa fa-trash"></i>
                                        <span>Delete All</span>
                                    </a>
                                </div>
                                <div class="sim">
                                    <p>Need help setting up divisions? Please <a href="#">get in touch</a>, we're happy to help!</p>
                                </div>
                                <div class="drw-mt">
                                    <table class="pp-edt">
                                        <div id="clip">
                                            <tr>
                                                <td rowspan="6">
                                                    <div class="dropdown show">
                                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="#" id="copy" data-clipboard-target=#clip><i class="fa fa-files-o"></i>Copy Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-clipboard"></i>Paste Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-up"></i>Move Up</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-down"></i>Move Down</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Above</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Below</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Split by Weight / Height</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Delete</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Clear Subdivisions</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="txt">0-12 years</a>
                                                    <p>Age</p>
                                                </td>
                                                <td rowspan="2">
                                                    <div class="dropdown show">
                                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-files-o"></i>Copy Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-clipboard"></i>Paste Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-up"></i>Move Up</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-down"></i>Move Down</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Above</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Below</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Split by Weight / Height</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Delete</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Clear Subdivisions</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="txt">10–6.gup</a>
                                                    <p>Rank</p>
                                                </td>
                                                <td>
                                                    <div class="dropdown show">
                                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-files-o"></i>Copy Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-clipboard"></i>Paste Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-up"></i>Move Up</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-down"></i>Move Down</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Above</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Below</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Split by Weight / Height</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Delete</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Clear Subdivisions</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="txt">Male</a>
                                                    <p>Gender</p>
                                                </td>
                                                <td><a href="#" class="splt">Split</a></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="dropdown show">
                                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-files-o"></i>Copy Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-clipboard"></i>Paste Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-up"></i>Move Up</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-down"></i>Move Down</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Above</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Below</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Split by Weight / Height</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Delete</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Clear Subdivisions</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="txt">Female</a>
                                                    <p>Gender</p>
                                                </td>
                                                <td><a href="#" class="splt">Split</a></td>
                                            </tr>
                                            <tr>
                                                <td rowspan="2">
                                                    <div class="dropdown show">
                                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-files-o"></i>Copy Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-clipboard"></i>Paste Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-up"></i>Move Up</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-down"></i>Move Down</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Above</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Below</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Split by Weight / Height</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Delete</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Clear Subdivisions</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="txt">5–1.gup</a>
                                                    <p>Rank</p>
                                                </td>
                                                <td>
                                                    <div class="dropdown show">
                                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-files-o"></i>Copy Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-clipboard"></i>Paste Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-up"></i>Move Up</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-down"></i>Move Down</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Above</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Below</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Split by Weight / Height</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Delete</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Clear Subdivisions</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="txt">Male</a>
                                                    <p>Gender</p>
                                                </td>
                                                <td><a href="#" class="splt">Split</a></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="dropdown show">
                                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-files-o"></i>Copy Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-clipboard"></i>Paste Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-up"></i>Move Up</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-down"></i>Move Down</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Above</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Below</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Split by Weight / Height</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Delete</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Clear Subdivisions</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="txt">Female</a>
                                                    <p>Gender</p>
                                                </td>
                                                <td><a href="#" class="splt">Split</a></td>
                                            </tr>
                                            <tr>
                                                <td rowspan="2">
                                                    <div class="dropdown show">
                                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-files-o"></i>Copy Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-clipboard"></i>Paste Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-up"></i>Move Up</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-down"></i>Move Down</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Above</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Below</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Split by Weight / Height</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Delete</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Clear Subdivisions</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="txt">1.dan+</a>
                                                    <p>Rank</p>
                                                </td>
                                                <td>
                                                    <div class="dropdown show">
                                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-files-o"></i>Copy Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-clipboard"></i>Paste Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-up"></i>Move Up</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-down"></i>Move Down</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Above</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Below</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Split by Weight / Height</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Delete</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Clear Subdivisions</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="txt">Male</a>
                                                    <p>Gender</p>
                                                </td>
                                                <td><a href="#" class="splt">Split</a></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="dropdown show">
                                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        </a>

                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-files-o"></i>Copy Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-clipboard"></i>Paste Subdivisions</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-up"></i>Move Up</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-arrow-down"></i>Move Down</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Above</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Insert Below</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-plus"></i>Split by Weight / Height</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Delete</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-times"></i>Clear Subdivisions</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="txt">Female</a>
                                                    <p>Gender</p>
                                                </td>
                                                <td><a href="#" class="splt">Split</a></td>
                                            </tr>
                                        </div>

                                    </table>
                                    <div class="seperate">
                                        <span></span>
                                    </div>
                                    <table class="ajbb">
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 13-17 years M 10–6.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 13-17 years M 10–6.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 13-17 years M 10–6.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 13-17 years M 10–6.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 13-17 years M 10–6.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 5–1.gup"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years M 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 0-12 years F 1.dan+"></td>
                                        </tr>
                                        <tr>
                                            <td><input class="km" type="text" name="num" placeholder="-"></td>
                                            <td><input class="zy" type="text" name="name" placeholder="Patterns 13-17 years M 10–6.gup"></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp_7_4\htdocs\world_kick_boxing\resources\views/frontend/event/edit_division.blade.php ENDPATH**/ ?>