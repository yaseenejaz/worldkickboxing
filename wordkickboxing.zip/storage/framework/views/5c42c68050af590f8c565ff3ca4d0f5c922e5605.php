<div class="col-xl-4">
    <nav class="nav-sidebar">
        <ul class="nav tabs">
            <li class="<?php echo e((request()->is('general')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('general')); ?>">General</a></li>
            <li class="<?php echo e((request()->is('registration_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('registration.setting')); ?>">Registration</a></li>
            <li class="<?php echo e((request()->is('venue_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('venue.setting')); ?>">Venue</a></li>
            <li class="<?php echo e((request()->is('image_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('image.setting')); ?>">Images</a></li>
            <li class="<?php echo e((request()->is('draw_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('draw.setting')); ?>">Draws</a></li>
            <li class="<?php echo e((request()->is('entry_fees_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('entry.setting')); ?>">Entry Fees</a></li>
            <li class="<?php echo e((request()->is('payment_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('payment.setting')); ?>">Payments</a></li>
            <li class="<?php echo e((request()->is('document_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('document.setting')); ?>">Documents</a></li>
            <li class="<?php echo e((request()->is('email_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('email.setting')); ?>">Emails</a></li>
            <li class="<?php echo e((request()->is('permission_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('permission.setting')); ?>">Permissions</a></li>
            <li class="<?php echo e((request()->is('result_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('result.setting')); ?>">Results</a></li>
            <li class="<?php echo e((request()->is('certificate_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('certificate.setting')); ?>">Certificates</a></li>
            <li class="<?php echo e((request()->is('weigh_in_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('weigh.setting')); ?>">Weigh-in</a></li>
            <li class="<?php echo e((request()->is('license_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('license.setting')); ?>">Licenses</a></li>
            <li class="<?php echo e((request()->is('physical_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('physical.setting')); ?>">Physical</a></li>
            <li class="<?php echo e((request()->is('data_setting')) ? 'sideNavActive' : ''); ?>"><a href="<?php echo e(route('data.setting')); ?>">Data</a></li>
        </ul>
    </nav>
</div>
<?php /**PATH E:\xampp_7_4\htdocs\world_kick_boxing\resources\views/frontend/setting/sidebar.blade.php ENDPATH**/ ?>