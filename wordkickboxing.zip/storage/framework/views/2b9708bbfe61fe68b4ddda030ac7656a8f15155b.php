<?php $__env->startSection('title'); ?>
    <title>Tournaments</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="inner-header">
        <h1>CREATE TOURNAMENT</h1>
    </section>

    <section class="tournament">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="kihap">
                        <h2>Tournaments hosted with Kihapp</h2>
                    </div>
                </div>
                <div class="col-xl-12">
                    <div class="tabs">
                        <div class="switch">
                            <a href="#">Anywhere</a>
                        </div>
                        <div class="switch">
                            <a href="#">Australia</a>
                        </div>
                        <div class="switch">
                            <a href="#">Belgium</a>
                        </div>
                        <div class="switch">
                            <a href="#">Canada</a>
                        </div>
                        <div class="switch">
                            <a href="#">Finland</a>
                        </div>
                        <div class="switch">
                            <a href="#">Germany</a>
                        </div>
                    </div>
                    <div class="tabs">
                        <div class="switch">
                            <a href="#">India</a>
                        </div>
                        <div class="switch">
                            <a href="#">Ireland</a>
                        </div>
                        <div class="switch">
                            <a href="#">Latvia</a>
                        </div>
                        <div class="switch">
                            <a href="#">Netherland</a>
                        </div>
                        <div class="switch">
                            <a href="#">Poland</a>
                        </div>
                        <div class="switch">
                            <a href="#">Swedan</a>
                        </div>
                    </div>
                    <div class="tabs">
                        <div class="switch">
                            <a href="#">United Kingdom</a>
                        </div>
                        <div class="switch">
                            <a href="#">United States</a>
                        </div>
                    </div>
                    <a href="<?php echo e(route('tournament.create')); ?>" class="create-tournament">Create Tournament</a>
                </div>

                <div class="col-xl-12">
                     <?php if(auth()->check()): ?>
                       <?php if(!empty($tournamentt)): ?>
                    <div class="ut">
                        <h2> Your Upcoming Tournaments</h2>
                     <?php $__currentLoopData = $tournament; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournaments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="matches">
                                <div class="imag">

                                </div>
                                <div class="det">
                                    <div class="txt">
                                        <a href="<?php echo e(route('show.tournament', $tournaments->slug)); ?>" class="lnk"><?php echo e($tournaments->name); ?></a>
                                        <span><?php echo e($tournaments->tournamentVenue->name ?? ''); ?></span>
                                        <?php
                                            $date = explode("-",$tournaments->date);
                                            $month = DateTime::createFromFormat('!m', $date[1]);
                                            $month = $month->format('F');
                                            $today = date(" " . $date[2] . ", " . $date[0]);
                                        ?>
                                        <span><?php echo e($month . $today); ?></span>
                                    </div>
                                    <div class="flag">
                                        <img src="<?php echo e(asset('frontend/images/india.png')); ?>">
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php endif; ?>
                    <div class="ut">
                        <h2>Upcoming Tournaments</h2>

                        <?php $__currentLoopData = $tournamentt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournaments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="matches">
                                <div class="imag">

                                </div>
                                <div class="det">
                                    <div class="txt">
                                        <a href="<?php echo e(route('show.tournament', $tournaments->slug)); ?>" class="lnk"><?php echo e($tournaments->name); ?></a>
                                        <span><?php echo e($tournaments->tournamentVenue->name ?? ''); ?></span>
                                        <?php
                                            $date = explode("-",$tournaments->date);
                                            $month = DateTime::createFromFormat('!m', $date[1]);
                                            $month = $month->format('F');
                                            $today = date(" " . $date[2] . ", " . $date[0]);
                                        ?>
                                        <span><?php echo e($month . $today); ?></span>
                                    </div>
                                    <div class="flag">
                                        <img src="<?php echo e(asset('frontend/images/india.png')); ?>">
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="past-tour">
                            <h3>Past Tournaments</h3>

                               <?php if(!empty($tournamen)): ?>
                        <?php $__currentLoopData = $tournamen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournamens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="matches">
                                <div class="imag">

                                </div>
                                <div class="det">
                                    <div class="txt">
                                        <a href="<?php echo e(route('show.tournament', $tournamens->slug)); ?>" class="lnk"><?php echo e($tournamens->name); ?></a>
                                        <span><?php echo e($tournamens->tournamenVenue->name ?? ''); ?></span>
                                        <?php
                                            $date = explode("-",$tournamens->date);
                                            $month = DateTime::createFromFormat('!m', $date[1]);
                                            $month = $month->format('F');
                                            $today = date(" " . $date[2] . ", " . $date[0]);
                                        ?>
                                        <span><?php echo e($month . $today); ?></span>
                                    </div>
                                    <div class="flag">
                                        <img src="<?php echo e(asset('frontend/images/india.png')); ?>">
                                    </div>
                                </div>
                            </div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>

                            <a href="#" class="lnk">There was an error fetching more tournaments. Please refresh and try again.</a>
                        </div>
                       <?php endif; ?>

                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\world_kick_boxing\resources\views/frontend/tournament/index.blade.php ENDPATH**/ ?>