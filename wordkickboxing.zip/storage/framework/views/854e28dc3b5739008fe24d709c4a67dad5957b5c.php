<?php $__env->startSection('title'); ?>
    <title>New Event</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <link rel="stylesheet" type="text/css"
          href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <section class="untitled">
        <h2><?php echo e($tournamentUser->name); ?></h2>
        <?php
            $date = explode("-",$tournamentUser->date);
            $month = DateTime::createFromFormat('!m', $date[1]);
            $month = $month->format('F');
            $today = date(" " . $date[2] . ", " . $date[0]);
        ?>
        <span><?php echo e($month . $today); ?></span>
    </section>

    <?php echo $__env->make('frontend.setting.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section>
        <div class="compe">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <?php if($tournamentUser->tournamentUser->email == ''): ?>
                            <p>Complete your profile so you'll be able log in later. <a
                                    href="<?php echo e(route('account.setting', $tournamentUser->tournamentUser->slug)); ?>">Profile</a>
                            </p>
                        <?php endif; ?>
                        <div class="ev-set">
                            <h2>New Event</h2>
                            <form method="post" action="<?php echo e(route('create.new.tournament.event')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="slug" value="<?php echo e($slug); ?>">
                                <div class="n-ev">
                                    <div class="lst">
                                        <label>Discipline</label>
                                        <div class="sel-down">
                                            <select name="descipline">
                                                <?php $__currentLoopData = $martialArt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $martialArts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <optgroup label="<?php echo e($martialArts->name); ?>">
                                                        <?php $__currentLoopData = $martialArts->descipline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desciplines): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option
                                                                value="<?php echo e($desciplines->id); ?>"><?php echo e($desciplines->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="lst">
                                        <label>Name</label>
                                        <input type="text" name="name">
                                    </div>
                                    <div class="lst">
                                        <label>Format</label>
                                        <div class="c-box">
                                            <?php $__currentLoopData = \App\Descipline::desciplineFormat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desciplineFormat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="rdio-btn">
                                                    <input <?php echo e($desciplineFormat['checked']); ?> type="radio" name="formation"
                                                           value="<?php echo e($desciplineFormat['id']); ?>">
                                                    <div class="radio"></div>
                                                    <span>
											<h4><?php echo e($desciplineFormat['label']); ?></h4>
											<p><?php echo e($desciplineFormat['text']); ?></p>
										</span>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <div class="rdio-btn">
                                                <input type="checkbox" name="">
                                                <div class="radio"></div>
                                                <span>
											<h4>Use bronze matches (where possible)</h4>
										</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="lst">
                                        <div class="ajw">
                                            <a class="adv" href="#">
                                                Advanced<i class="fa fa-caret-right"></i>
                                            </a>
                                            <div class="adv-div">
                                                <div class="sec">
                                                    <label>Position</label>
                                                    <div class="or-sel">
                                                        <select name="position">
                                                            <?php for($i = 1; $i <= count($tournamentEventPosition) + 1; $i++): ?>
                                                                <?php if(count($tournamentEventPosition) + 1 == $i): ?>
                                                                    <option selected value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                                <?php else: ?>
                                                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                                <?php endif; ?>
                                                            <?php endfor; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="sec">
                                                    <label>Initial Divisions</label>
                                                    <div class="c-box">
                                                        <div class="rdio-btn">
                                                            <input type="radio" name="division" checked>
                                                            <div class="radio"></div>
                                                            <span>
														<h4>Default</h4>
													</span>
                                                        </div>
                                                        <div class="rdio-btn">
                                                            <input type="radio" name="division">
                                                            <div class="radio"></div>
                                                            <span>
														<h4>Blank</h4>
													</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <button style="border: none" type="submit" class="crt">Create</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script>

        jQuery(document).ready(function () {
            jQuery('.icon-menu').on('click', function () {

                jQuery('.nav-kick').slideToggle('fast');
            });

            jQuery('.adv').on('click', function (e) {
                e.preventDefault();
                jQuery('.adv-div').toggleClass('active');
            });

        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\world_kick_boxing\resources\views/frontend/event/new_event.blade.php ENDPATH**/ ?>