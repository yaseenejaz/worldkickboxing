<ul class="nav nav-tabs">
    <li class="nav-item <?php echo e((request()->is('guest')) ? 'navActive' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('guest')); ?>"><i class="fa fa-user"></i>Your Profile</a>
    </li>
    <li class="nav-item <?php echo e((request()->is('billing')) ? 'navActive' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('billing')); ?>"><i class="fa fa-usd"></i>Billing</a>
    </li>
    <li class="nav-item <?php echo e((request()->is('account_setting')) ? 'navActive' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('account.setting')); ?>"><i class="fa fa-cog"></i>Account Settings</a>
    </li>
    <li class="nav-item <?php echo e((request()->is('stripe')) ? 'navActive' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('stripe')); ?>"><i class="fa fa-cc-stripe"></i>Stripe Setup</a>
    </li>
    <li class="nav-item <?php echo e((request()->is('paypal')) ? 'navActive' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('paypal')); ?>"><i class="fa fa-paypal"></i>Paypal Setup</a>
    </li>
</ul>
<?php /**PATH E:\xampp_7_4\htdocs\world_kick_boxing\resources\views/frontend/guestUser/navHeader.blade.php ENDPATH**/ ?>