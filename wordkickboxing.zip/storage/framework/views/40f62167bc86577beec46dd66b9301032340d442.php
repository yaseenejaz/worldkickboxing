<?php $__env->startSection('title'); ?>
    <title>Profile</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <style>
        .navActive {
            transition: all 0.5s ease;
            background: #df4428;
            border-radius: 5px;
            color: #fff !important;
        }

        .navActive a{
            color: #fff !important;
        }
    </style>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="untitled">
        <h2>Untitled Tournament</h2>
        <span>May 20,2020</span>
    </section>
    <?php echo $__env->make('frontend.guestUser.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="ver-tab">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <h2>Guest</h2>
                    <div class="pow-in">
                        <?php echo $__env->make('frontend.guestUser.navHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div>
                            <div class="pf">
                                <div class="nt">
                                    <a href="<?php echo e(route('tournament.create')); ?>"><i class="fa fa-plus"></i>New Tournament</a>
                                    <a href="#"><i class="fa fa-plus"></i>New Ranking</a>
                                </div>
                                <div class="tb-in">
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item" id="tournament-tab" data-toggle="tab" href="#tournament" role="tab" aria-controls="tournament" aria-selected="true">
                                            <a class="nav-link" href="#">Tournament</a>
                                        </li>
                                        <li class="nav-item" id="ranking-tab" data-toggle="tab" href="#ranking" role="tab" aria-controls="ranking" aria-selected="true">
                                            <a class="nav-link" href="#">Ranking</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade active in" id="tournament" role="tabpanel" aria-labelledby="tournament-tab">
                                            <div class="t-box">
                                                <div class="mth">
                                                    <div class="pic">
                                                    </div>
                                                    <div class="txt">
                                                        <a href="#">Untitled Tournament</a>
                                                        <p>June 16, 2020</p>
                                                    </div>
                                                </div>
                                                <div class="mth">
                                                    <div class="pic">
                                                    </div>
                                                    <div class="txt">
                                                        <a href="#">Untitled Tournament</a>
                                                        <p>June 16, 2020</p>
                                                    </div>
                                                </div>
                                                <div class="mth">
                                                    <div class="pic">
                                                    </div>
                                                    <div class="txt">
                                                        <a href="#">Untitled Tournament</a>
                                                        <p>June 16, 2020</p>
                                                    </div>
                                                </div>
                                                <div class="mth">
                                                    <div class="pic">
                                                    </div>
                                                    <div class="txt">
                                                        <a href="#">Untitled Tournament</a>
                                                        <p>June 16, 2020</p>
                                                    </div>
                                                </div>
                                                <div class="mth">
                                                    <div class="pic">
                                                    </div>
                                                    <div class="txt">
                                                        <a href="#">Untitled Tournament</a>
                                                        <p>June 16, 2020</p>
                                                    </div>
                                                </div>
                                                <div class="mth">
                                                    <div class="pic">
                                                    </div>
                                                    <div class="txt">
                                                        <a href="#">Untitled Tournament</a>
                                                        <p>June 16, 2020</p>
                                                    </div>
                                                </div>
                                                <div class="mth">
                                                    <div class="pic">
                                                    </div>
                                                    <div class="txt">
                                                        <a href="#">Untitled Tournament</a>
                                                        <p>June 16, 2020</p>
                                                    </div>
                                                </div>
                                                <div class="mth">
                                                    <div class="pic">
                                                    </div>
                                                    <div class="txt">
                                                        <a href="#">Untitled Tournament</a>
                                                        <p>June 16, 2020</p>
                                                    </div>
                                                </div>
                                                <div class="mth">
                                                    <div class="pic">
                                                    </div>
                                                    <div class="txt">
                                                        <a href="#">Untitled Tournament</a>
                                                        <p>June 16, 2020</p>
                                                    </div>
                                                </div>
                                                <div class="mth">
                                                    <div class="pic">
                                                    </div>
                                                    <div class="txt">
                                                        <a href="#">Untitled Tournament</a>
                                                        <p>June 16, 2020</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="ranking" role="tabpanel" aria-labelledby="ranking-tab">
                                            <div class="ran">
                                                <div class="bax">
                                                    <p>Once you've created a ranking, it will appear here.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp_7_4\htdocs\world_kick_boxing\resources\views/frontend/guestUser/profile.blade.php ENDPATH**/ ?>