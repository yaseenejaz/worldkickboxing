<?php $__env->startSection('title'); ?>
    <title>Competitors | <?php echo e($slug); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <style>
        .navActive {
            transition: all 0.5s ease;
            background: #df4428;
            border-radius: 5px;
            color: #fff !important;
        }

        .navActive a {
            color: #fff !important;
        }
    </style>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet"
          id="bootstrap-css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="untitled">
        <h2><?php echo e($tournament->name); ?></h2>
        <?php
        $date = explode("-", $tournament->date);
        $month = DateTime::createFromFormat('!m', $date[1]);
        $month = $month->format('F');
        $today = date(" " . $date[2] . ", " . $date[0]);
        ?>
        <span><?php echo e($month . $today); ?></span>
    </section>
    <?php echo $__env->make('frontend.tournament.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="ver-tab">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <h2><?php echo e($event->name); ?></h2>
                    <div class="pow-in">
                        <?php echo $__env->make('frontend.event.navHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade active in" id="setting" role="tabpanel"
                                 aria-labelledby="setting-tab">
                                <div class="ev-set pat-ev-set">
                                    <h2>Setting</h2>
                                    <div class="n-ev">
                                        <div class="lst">
                                            <label>Discipline</label>
                                            <div class="sel-down">
                                                <select name="descipline">
                                                    <?php $__currentLoopData = $descipline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desciplines): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($event->descipline_id == $desciplines->id): ?>
                                                            <option value="<?php echo e($desciplines->id); ?>" selected><?php echo e($desciplines->name); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($desciplines->id); ?>"><?php echo e($desciplines->name); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="lst">
                                            <label>Format</label>
                                            <div class="c-box">
                                                <?php $__currentLoopData = \App\Descipline::desciplineFormat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desciplineFormat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="rdio-btn">
                                                        <input <?php echo e($desciplineFormat['checked']); ?> type="radio"
                                                               name="formation"
                                                               value="<?php echo e($desciplineFormat['id']); ?>">
                                                        <div class="radio"></div>
                                                        <span>
											<h4><?php echo e($desciplineFormat['label']); ?></h4>
											<p><?php echo e($desciplineFormat['text']); ?></p>
										</span>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <div class="rdio-btn">
                                                    <input type="checkbox" name="check">
                                                    <div class="radio"></div>
                                                    <span>
												<h4>Use 3rd place matches</h4>
											</span>
                                                </div>
                                                <div class="rdio-btn">
                                                    <input type="checkbox" name="check">
                                                    <div class="radio"></div>
                                                    <span>
												<h4>Prevent online registrations</h4>
											</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="lst">
                                            <label>*Name</label>
                                            <input type="text" name="name" placeholder="Pattern" value="<?php echo e($event->name); ?>">
                                        </div>
                                        <div class="lst">
                                            <label>Identifier</label>
                                            <input type="text" name="name" placeholder="P" value="<?php echo e($event->identifier); ?>">
                                        </div>
                                        <div class="lst">
                                            <label>Position</label>
                                            <div class="sel-down">
                                                <select name="position">
                                                    <?php for($i = 1; $i <= count($tournamentEventPosition); $i++): ?>
                                                        <?php if($event->position == $i): ?>
                                                            <option selected value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="lst">
                                            <label>Cover Photo</label>
                                            <input type="file" name="file" class="fle-bx">
                                        </div>
                                        <div class="lst">
                                            <div class="ajw">
                                                <p>Scoreboard ITF Patterns (10/6/6/6/6)</p>
                                                <a href="#" class="crt">Save</a>
                                            </div>
                                        </div>
                                        <div class="lst">
                                            <div class="ajw">
                                                <h2>Remove</h2>
                                                <a href="#" class="crt">Remove</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp_7_4\htdocs\world_kick_boxing\resources\views/frontend/event/setting.blade.php ENDPATH**/ ?>