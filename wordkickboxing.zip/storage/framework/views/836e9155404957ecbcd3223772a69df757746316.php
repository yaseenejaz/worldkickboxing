<?php $__env->startSection('title'); ?>
    <title>Account Setting</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('link'); ?>
    <style>
        .navActive {
            transition: all 0.5s ease;
            background: #df4428;
            border-radius: 5px;
            color: #fff !important;
        }

        .navActive a {
            color: #fff !important;
        }

        .save_button {
            background: #e04529;
            color: #fff;
            padding: 10px 30px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.5s ease;
            border: none;
        }

        .save_button:hover {
            transition: all 0.5s ease;
            background: #000;
        }
    </style>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet"
          id="bootstrap-css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="untitled">
        <h2><?php echo e(auth()->user()->name); ?></h2>
    </section>
    <?php echo $__env->make('frontend.user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="ver-tab">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <h2>Account Setting</h2>
                    <div class="pow-in">
                        <?php echo $__env->make('frontend.user.navHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div>
                            <?php if(auth()->user()->email == ""): ?>
                                <form method="post" action="<?php echo e(route('guest.info.update')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="pf">
                                        <h2>Your Details</h2>
                                        <div class="fmr">
                                            <div class="fld">
                                                <label>Name</label>
                                                <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       type="text" name="name" value="<?php echo e($user->name); ?>">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p style="padding-left: 115px" class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="fld">
                                                <label>Email</label>
                                                <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       type="email" name="email" value="<?php echo e($user->email); ?>">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p style="padding-left: 115px" class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="fld">
                                                <label>New Password</label>
                                                <input type="Password" name="password"
                                                       class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       id="password" autocomplete="new-password">
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p style="padding-left: 115px" class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="fld">
                                                <label>Confirm Password</label>
                                                <input id="password-confirm" type="password" class="form-control"
                                                       name="password_confirmation" autocomplete="new-password">
                                            </div>
                                            <div class="fld">
                                                <div class="wt-lab">
                                                    <div class="rad-txt">
                                                        <?php
                                                        if ($user->remind == 1) {
                                                            $checked = 'checked';
                                                        } else {
                                                            $checked = '';
                                                        }
                                                        ?>
                                                        <input type="checkbox" name="remind_me" value="1" <?php echo e($checked); ?>>
                                                        <div class="rado"></div>
                                                    </div>
                                                    <p>Email me about new features and tournaments.</p>
                                                </div>
                                            </div>
                                            <div class="fld">
                                                <div class="wt-lab">
                                                    <button class="save_button" type="submit">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            <?php else: ?>
                                <form method="post" action="<?php echo e(route('user.info.update')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="pf">
                                        <h2>Your Details</h2>
                                        <div class="fmr">
                                            <div class="fld">
                                                <label>Name</label>
                                                <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                                       name="name" value="<?php echo e($user->name); ?>">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p style="padding-left: 115px" class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="fld">
                                                <label>Email</label>
                                                <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       type="email" name="email" value="<?php echo e($user->email); ?>">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p style="padding-left: 115px" class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="fld">
                                                <div class="wt-lab">
                                                    <div class="rad-txt">
                                                        <?php
                                                        if ($user->remind == 1) {
                                                            $checked = 'checked';
                                                        } else {
                                                            $checked = '';
                                                        }
                                                        ?>
                                                        <input type="checkbox" name="remind_me" value="1" <?php echo e($checked); ?>>
                                                        <div class="rado"></div>
                                                    </div>
                                                    <p>Email me about new features and tournaments.</p>
                                                </div>
                                            </div>
                                            <div class="fld">
                                                <div class="wt-lab">
                                                    <button class="save_button" type="submit">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <form method="post" action="<?php echo e(route('user.password.update')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="pf">
                                        <h2>Change Password</h2>
                                        <div class="fmr">
                                            <div class="fld">
                                                <label>Old Password</label>
                                                <input type="Password" name="old_password">
                                            </div>
                                            <div class="fld">
                                                <label>New Password</label>
                                                <input type="Password" name="password"
                                                       class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p style="padding-left: 115px" class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="fld">
                                                <div class="wt-lab">
                                                    <button class="save_button" type="submit">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function () {

            <?php if(\Session::has('message')): ?>
            $.toast({
                heading: 'Success!',
                position: 'top-center',
                text: '<?php echo e(session()->get('message')); ?>',
                loaderBg: '#ff6849',
                icon: 'success',
                hideAfter: 3000,
                stack: 6
            });
            <?php endif; ?>

            <?php if(\Session::has('password')): ?>
            $.toast({
                heading: 'Success!',
                position: 'top-center',
                text: '<?php echo e(session()->get('password')); ?>',
                loaderBg: '#ff6849',
                icon: 'success',
                hideAfter: 3000,
                stack: 6
            });
            <?php endif; ?>

            <?php if(\Session::has('error')): ?>
            $.toast({
                heading: 'Error',
                position: 'top-center',
                text: '<?php echo e(session()->get('error')); ?>',
                loaderBg: '#a94442',
                icon: 'error',
                hideAfter: 3000,
                stack: 6,
            });
            <?php endif; ?>
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp_7_4\htdocs\world_kick_boxing\resources\views/frontend/user/account_setting.blade.php ENDPATH**/ ?>